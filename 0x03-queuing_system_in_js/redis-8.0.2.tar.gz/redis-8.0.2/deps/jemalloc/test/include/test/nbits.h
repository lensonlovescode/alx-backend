#ifndef TEST_NBITS_H
#define TEST_NBITS_H

/* Interesting bitmap counts to test. */

#define NBITS_TAB \
    NB( 1) \
    NB( 2) \
    NB( 3) \
    NB( 4) \
    NB( 5) \
    NB( 6) \
    NB( 7) \
    NB( 8) \
    NB( 9) \
    NB(10) \
    NB(11) \
    NB(12) \
    NB(13) \
    NB(14) \
    NB(15) \
    NB(16) \
    NB(17) \
    NB(18) \
    NB(19) \
    NB(20) \
    NB(21) \
    NB(22) \
    NB(23) \
    NB(24) \
    NB(25) \
    NB(26) \
    NB(27) \
    NB(28) \
    NB(29) \
    NB(30) \
    NB(31) \
    NB(32) \
    \
    NB(33) \
    NB(34) \
    NB(35) \
    NB(36) \
    NB(37) \
    NB(38) \
    NB(39) \
    NB(40) \
    NB(41) \
    NB(42) \
    NB(43) \
    NB(44) \
    NB(45) \
    NB(46) \
    NB(47) \
    NB(48) \
    NB(49) \
    NB(50) \
    NB(51) \
    NB(52) \
    NB(53) \
    NB(54) \
    NB(55) \
    NB(56) \
    NB(57) \
    NB(58) \
    NB(59) \
    NB(60) \
    NB(61) \
    NB(62) \
    NB(63) \
    NB(64) \
    NB(65) \
    NB(66) \
    NB(67) \
    \
    NB(126) \
    NB(127) \
    NB(128) \
    NB(129) \
    NB(130) \
    \
    NB(254) \
    NB(255) \
    NB(256) \
    NB(257) \
    NB(258) \
    \
    NB(510) \
    NB(511) \
    NB(512) \
    NB(513) \
    NB(514) \
    \
    NB(1022) \
    NB(1023) \
    NB(1024) \
    NB(1025) \
    NB(1026) \
    \
    NB(2048) \
    \
    NB(4094) \
    NB(4095) \
    NB(4096) \
    NB(4097) \
    NB(4098) \
    \
    NB(8192) \
    NB(16384)

#endif /* TEST_NBITS_H */
